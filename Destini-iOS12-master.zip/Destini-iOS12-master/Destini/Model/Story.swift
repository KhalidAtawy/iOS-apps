//
//  Story.swift
//  Destini
//
//  Created by Khalid Saleh Elatawy on 1/10/19.
//  Copyright © 2019 London App Brewery. All rights reserved.
//

import Foundation

class Story {
    
    let storyTxt : String
    
    let answerA : String
    let answerB : String
    
    let nextQuestionNum_A : Int
    let nextQuestionNum_B : Int
    
    let end : Bool
    
    init(text : String, text_A : String, text_B : String, nextA : Int, nextB : Int, isEnd : Bool) {
        
        storyTxt = text
        answerA = text_A
        answerB = text_B
        nextQuestionNum_A = nextA
        nextQuestionNum_B = nextB
        end = isEnd
    }
    
}
