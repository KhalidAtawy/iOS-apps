//
//  ViewController.swift
//  Dicee
//
//  Created by Khalid Saleh Elatawy on 12/19/18.
//  Copyright © 2018 Khalid Saleh Elatawy. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    let imageArray = ["dice1", "dice2", "dice3", "dice4", "dice4", "dice5", "dice6"]
    
    @IBOutlet weak var diceImage_L: UIImageView!
    @IBOutlet weak var diceImage_R: UIImageView!
    
    //creating variables for the random generation
    var randomImageIndex_L: Int = 0
    var randomImageIndex_R: Int = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        updateDiceImage()
    }


    @IBAction func rollButtonPressed(_ sender: UIButton) {
        updateDiceImage()
    }
    
    override func motionEnded(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        updateDiceImage()
    }
    
    //function that picks two images from an array based on random number
    func updateDiceImage () {
        //we will add + 1 for the Left because we will try to call it without the array, wont start form 0
        randomImageIndex_L = Int.random(in: 0...5) + 1
        randomImageIndex_R = Int.random(in: 0...5)
        
        // trying two ways of picking the image
        diceImage_L.image = UIImage(named: "dice"+"\(randomImageIndex_L)")
        diceImage_R.image = UIImage(named: imageArray[randomImageIndex_R])
        
    }
}

